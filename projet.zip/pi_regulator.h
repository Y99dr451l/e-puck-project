#ifndef PI_REGULATOR_H
#define PI_REGULATOR_H

int16_t* get_speeds(void);
int16_t* get_speedrot(void);
void pi_regulator_start(void);

#endif /* PI_REGULATOR_H */
